
@extends('public.layouts.main')




  @section('content')
    @include('public.includes.carousel')
    @include('public.includes.search')
    @include('public.includes.category')
    @include('public.includes.about')
    @include('public.includes.joblist')
    @include('public.includes.testimonial')
  @endsection

 
