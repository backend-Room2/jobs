<!DOCTYPE html>
<html lang="en">

  <?php echo $__env->make('public/includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <body>
  <?php echo $__env->make('public/includes.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('public/includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <?php echo $__env->yieldContent('content'); ?>




 <?php echo $__env->make('public/includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php echo $__env->make('public/includes.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel-jobs\resources\views/public/layouts/main.blade.php ENDPATH**/ ?>